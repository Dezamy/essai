package com.dam.damsport;

public class AuthUI {
    public static void getInstance() {
    }

    public static class IdpConfig {
        public static class EmailBuilder {
            public void build() {
            }
        }

        public static class PhoneBuilder {
            public void build() {
            }
        }

        public static class GoogleBuilder {
            public void build() {
            }
        }

//        public static class FacebookBuilder {
//        }
//
//        public static class TwitterBuilder {
//        }
    }
}
