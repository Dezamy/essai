package com.dam.damsport;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import org.w3c.dom.Text;

public class enregistrer extends AppCompatActivity implements View.OnClickListener{

    EditText  editTxtmailAddress;
    EditText editTxtNumberPassword;
    Button btnSinscrire;
    Button btnConnexion;
    Button btnMotDePassOublier;
    Button btnGmail;
    Button btnFacebook;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enregistrer);
        editTxtmailAddress = (EditText)findViewById(R.id.editTxtmailAddress);
        editTxtNumberPassword = (EditText)findViewById(R.id.editTxtNumberPassword);
        btnSinscrire = (Button)findViewById(R.id.btnSinscrire);
        btnConnexion = (Button) findViewById(R.id.btnConnexion);
        btnMotDePassOublier = (Button) findViewById(R.id.btnMotDePassOublier);
        btnGmail = (Button)findViewById(R.id.btnGmail);
        btnFacebook = (Button)findViewById(R.id.btnFacebook);

        editTxtmailAddress.setOnClickListener(this);
        editTxtNumberPassword.setOnClickListener(this);
        btnConnexion.setOnClickListener(this);
        btnMotDePassOublier.setOnClickListener(this);
        btnGmail.setOnClickListener(this);
        btnFacebook.setOnClickListener(this);
        btnSinscrire.setOnClickListener(this);

    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.editTxtmailAddress:
                sendToast("vouqs avez cliquer sur le Mail");
                break;
            case R.id.editTxtNumberPassword:
                sendToast("Saisissez votre Mot de Passe");
                break;
            case R.id.btnConnexion:
                sendToast("vous avez cliquer sur le bouton connexion");
                break;
            case R.id.btnMotDePassOublier:
                sendToast("Un mail vous à été envoyer");
                break;
            case R.id.btnGmail:
                sendToast("Se connecter avec votre compte Gmail");
                break;
            case R.id.btnFacebook:
                sendToast("Se connecter avec votre compte Facebook");
                break;
            case R.id.btnSinscrire:
                sendToast("Vous allez etre diriger vers la page d'inscription");

                Intent intent = new Intent(this,Utilisateur.class);
            startActivity(intent);
            break;
        }

    }

    private void startActivities(Intent intent) {
    }

    private void sendToast(String message ){
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();

    }


    public void change(View view) {
    }
}