package com.dam.damsport;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.parcouractivity.R;

public class MapFragment extends Fragment {
    Button btnGo;
    Button btnEtape;
    Button btnFin;
    FragmentManager fragmentManager;
    FragmentTransaction transaction;
    public MapFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_map, container, false);
        btnGo = view.findViewById(R.id.btnGo);
        btnEtape = view.findViewById(R.id.btnGo);
        btnFin = view.findViewById(R.id.btnFin);
        btnFin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFragmentValider(546542);
            }
        });

        return view;


    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void startFragmentValider (long idtrajet) {
        ValiderFragment validerFragment = new ValiderFragment();
        Bundle bundle = new Bundle();
        bundle.putLong("idtrajet", idtrajet );
        validerFragment.setArguments(bundle);
        openFragment (validerFragment,"valider");
    }

    public void openFragment (Fragment frag, String tag) {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.body_holder, frag);
        transaction.addToBackStack(tag);
        transaction.commit();
    }
}