package com.dam.damsport;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.parcouractivity.R;

public class ValiderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_valider);
    }
}