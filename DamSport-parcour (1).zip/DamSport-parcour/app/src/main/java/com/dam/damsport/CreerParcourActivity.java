package com.dam.damsport;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.example.parcouractivity.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class CreerParcourActivity extends FragmentActivity {
    FloatingActionButton flbtn;
    FragmentManager fragmentManager;
    FragmentTransaction transaction;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creer_parcour);
        fragmentManager = this.getSupportFragmentManager();
        MapFragment mf = new MapFragment();
        openFragment(mf,"map");
    }

    public void openFragment (Fragment frag, String tag) {
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.body_holder, frag);
        transaction.addToBackStack(tag);
        transaction.commit();
    }
}