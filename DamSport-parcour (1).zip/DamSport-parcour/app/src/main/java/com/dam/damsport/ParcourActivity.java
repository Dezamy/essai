package com.dam.damsport;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.parcouractivity.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ParcourActivity extends AppCompatActivity {
    FloatingActionButton flParcour;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcour);
        flParcour = (FloatingActionButton) findViewById(R.id.flparcour);

        flParcour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txt = "Creer un parcours";
                Intent intent = new Intent(ParcourActivity.this,CreerParcourActivity.class );
                intent.putExtra("titre",txt);
                startActivity(intent);
            }
        });
    }
}