package com.dam.damsport;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.Timer;
import java.util.TimerTask;

public class LayoutTempsTotal extends FragmentActivity {

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    Context tContext;
    ExerciceDefini fragmentExo;

    Timer temps = new Timer();
    long initTime = System.currentTimeMillis();

    TimerTask timerTask = new TimerTask() {

        @Override
        public void run() {
            while(isLaunch()) {

                /*
                System.currentTimeMillis() est un compteur de temps depuis le lancement de linux
                on soustrait cette valeur par lui meme en dehors de la methode
                 */
                long temps = System.currentTimeMillis() - initTime ;

               /*
                apres 1000 millisecond il ajoute 1 seconde
                apres 60000 millisecond il ajoute 1 minute
                apres 3600000 millisecond il ajoute 1 heure
                 */
                int millis = (int) temps % 1000;
                int seconds = (int) (temps / 1000) % 60;
                int minutes = (int) ((temps / 60000) % 60);
                int hours = (int) ((temps / 3600000));

                //reprendre selon les regles de l'arts a traiter dans le thread UI
                textChrono.setText(Long.toString(hours)+":"+ Long.toString(minutes)+":"+
                        Long.toString(seconds)+":"+Long.toString(millis));

            }
        }
    };

    Button btPlay, btPause, btStop;
    TextView textChrono;

    Boolean isTrue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_temps_total);

        init();

        btPlay.setOnClickListener(view -> {
            temps.schedule(timerTask, 0);
            isTrue = true;
            fragmentExo.start();
        });

        btPause.setOnClickListener(view -> {
            isTrue = false;
            fragmentExo.pause();
        });

        btStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isTrue = false;
                fragmentExo.stop();

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
//        fragmentExo = (ExerciceDefini) fragmentManager.findFragmentByTag("tagFragmentExo");

    }

    private Boolean isLaunch(){
        return isTrue;
    }

    private void init(){
        btPlay = (Button) findViewById(R.id.idLecture);
        btPause = (Button) findViewById(R.id.idPause);
        btStop = (Button) findViewById(R.id.idStop);

        textChrono = (TextView) findViewById(R.id.idTimer);
    }

}