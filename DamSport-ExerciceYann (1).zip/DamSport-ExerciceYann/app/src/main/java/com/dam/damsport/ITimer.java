package com.dam.damsport;

public interface ITimer {
    public void start();
    public void pause();
    public void stop();
}
